"use client"

import type React from "react"

import { useState } from "react"
import { Mail, Phone, MapPin, Send } from "lucide-react"

export default function Contact() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    message: "",
  })

  const [submitted, setSubmitted] = useState(false)

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    // Simulation d'envoi
    setSubmitted(true)
    setTimeout(() => {
      setFormData({ name: "", email: "", phone: "", message: "" })
      setSubmitted(false)
    }, 3000)
  }

  return (
    <section id="contact" className="py-20 bg-white">
      <div className="max-w-6xl mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-4xl md:text-5xl font-bold text-black mb-4">
            Nous <span className="text-red-600">Contacter</span>
          </h2>
          <p className="text-gray-600 text-lg">Des questions ? N'hésitez pas à nous envoyer un message</p>
        </div>

        <div className="grid md:grid-cols-2 gap-12">
          {/* Informations de contact */}
          <div className="space-y-8">
            <div className="flex gap-4 items-start">
              <div className="w-12 h-12 bg-red-600 rounded-lg flex items-center justify-center flex-shrink-0">
                <Phone size={24} className="text-white" />
              </div>
              <div>
                <h3 className="font-bold text-lg text-black mb-1">Téléphone</h3>
                <p className="text-gray-600">06 81 44 52 13</p>
                <p className="text-gray-500 text-sm mt-1">Disponible du lundi au samedi</p>
              </div>
            </div>

            <div className="flex gap-4 items-start">
              <div className="w-12 h-12 bg-red-600 rounded-lg flex items-center justify-center flex-shrink-0">
                <Mail size={24} className="text-white" />
              </div>
              <div>
                <h3 className="font-bold text-lg text-black mb-1">Email</h3>
                <p className="text-gray-600">contact@akboxing.fr</p>
                <p className="text-gray-500 text-sm mt-1">Réponse en 24h</p>
              </div>
            </div>

            <div className="flex gap-4 items-start">
              <div className="w-12 h-12 bg-red-600 rounded-lg flex items-center justify-center flex-shrink-0">
                <MapPin size={24} className="text-white" />
              </div>
              <div>
                <h3 className="font-bold text-lg text-black mb-1">Adresse</h3>
                <p className="text-gray-600">123 Rue de la Boxe</p>
                <p className="text-gray-600">75000 Paris</p>
              </div>
            </div>

            {/* Horaires */}
            <div className="bg-black text-white p-6 rounded-lg">
              <h3 className="font-bold text-lg mb-4">Horaires d'ouverture</h3>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span>Lundi - Vendredi:</span>
                  <span className="text-red-600">15h - 22h</span>
                </div>
                <div className="flex justify-between">
                  <span>Samedi:</span>
                  <span className="text-red-600">09h - 14h</span>
                </div>
                <div className="flex justify-between">
                  <span>Dimanche:</span>
                  <span className="text-red-600">Fermé</span>
                </div>
              </div>
            </div>
          </div>

          {/* Formulaire de contact */}
          <div className="bg-gray-50 p-8 rounded-lg">
            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <label className="block text-black font-semibold mb-2">Nom complet</label>
                <input
                  type="text"
                  name="name"
                  value={formData.name}
                  onChange={handleChange}
                  required
                  className="w-full px-4 py-3 border-2 border-gray-300 rounded-lg focus:border-red-600 focus:outline-none transition"
                  placeholder="Votre nom"
                />
              </div>

              <div>
                <label className="block text-black font-semibold mb-2">Email</label>
                <input
                  type="email"
                  name="email"
                  value={formData.email}
                  onChange={handleChange}
                  required
                  className="w-full px-4 py-3 border-2 border-gray-300 rounded-lg focus:border-red-600 focus:outline-none transition"
                  placeholder="votre.email@exemple.com"
                />
              </div>

              <div>
                <label className="block text-black font-semibold mb-2">Téléphone</label>
                <input
                  type="tel"
                  name="phone"
                  value={formData.phone}
                  onChange={handleChange}
                  className="w-full px-4 py-3 border-2 border-gray-300 rounded-lg focus:border-red-600 focus:outline-none transition"
                  placeholder="06 XX XX XX XX"
                />
              </div>

              <div>
                <label className="block text-black font-semibold mb-2">Message</label>
                <textarea
                  name="message"
                  value={formData.message}
                  onChange={handleChange}
                  required
                  rows={5}
                  className="w-full px-4 py-3 border-2 border-gray-300 rounded-lg focus:border-red-600 focus:outline-none transition resize-none"
                  placeholder="Votre message..."
                ></textarea>
              </div>

              <button
                type="submit"
                disabled={submitted}
                className="w-full bg-red-600 hover:bg-red-700 disabled:bg-gray-400 text-white font-bold py-3 rounded-lg flex items-center justify-center gap-2 transition"
              >
                <Send size={20} />
                {submitted ? "Message envoyé ✓" : "Envoyer le message"}
              </button>

              {submitted && (
                <p className="text-green-600 text-center font-semibold">Merci ! Nous vous recontacterons bientôt.</p>
              )}
            </form>
          </div>
        </div>
      </div>
    </section>
  )
}
