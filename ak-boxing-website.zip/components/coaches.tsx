"use client"

const COACHES = [
  {
    id: 1,
    name: "Antoine Kébé",
    title: "Directeur & Coach Principal",
    experience: "15+ ans de boxe",
    specialty: "Technique générale",
    image: "/coach-boxe-homme-noir.jpg",
  },
  {
    id: 2,
    name: "Marie Dupont",
    title: "Coach Féminin",
    experience: "10+ ans d'expérience",
    specialty: "Cardio & Condition physique",
    image: "/placeholder-jknhs.png",
  },
  {
    id: 3,
    name: "Yves Martin",
    title: "Coach Junior",
    experience: "8 ans d'entraînement",
    specialty: "Cours enfants & préados",
    image: "/coach-jeune-boxe.jpg",
  },
  {
    id: 4,
    name: "Lisa Rousseau",
    title: "Coach Assistant",
    experience: "5 ans d'experience",
    specialty: "Mise de gants & Sparring",
    image: "/coach-boxe-femme-2.jpg",
  },
]

export default function Coaches() {
  return (
    <section id="coachs" className="py-20 bg-gray-50">
      <div className="max-w-6xl mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-4xl md:text-5xl font-bold text-black mb-4">Nos Entraîneurs</h2>
          <p className="text-gray-600 text-lg">Une équipe de professionnels expérimentés et passionnés</p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {COACHES.map((coach) => (
            <div
              key={coach.id}
              className="bg-white rounded-lg overflow-hidden shadow-lg hover:shadow-2xl transition transform hover:-translate-y-2"
            >
              <div className="aspect-square overflow-hidden bg-gray-200">
                <img
                  src={coach.image || "/placeholder.svg"}
                  alt={coach.name}
                  className="w-full h-full object-cover hover:scale-110 transition duration-300"
                />
              </div>
              <div className="p-6">
                <h3 className="text-xl font-bold text-black mb-1">{coach.name}</h3>
                <p className="text-red-600 font-semibold text-sm mb-2">{coach.title}</p>
                <p className="text-gray-600 text-sm mb-3">{coach.experience}</p>
                <p className="text-gray-700 text-sm border-t pt-3">
                  <span className="font-semibold">Spécialité:</span> {coach.specialty}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
