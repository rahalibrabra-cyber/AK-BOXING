"use client"

import { useState } from "react"
import { Menu, X } from "lucide-react"
import Image from "next/image"

export default function Navigation() {
  const [isOpen, setIsOpen] = useState(false)

  return (
    <nav className="fixed top-0 w-full bg-black text-white z-50 shadow-lg">
      <div className="max-w-6xl mx-auto px-4 py-4 flex justify-between items-center">
        <div className="flex items-center gap-3">
          <Image src="/images/image.png" alt="AK Boxing Logo" width={40} height={40} className="w-10 h-10" />
          <span className="font-bold text-xl">AK BOXING</span>
        </div>

        {/* Desktop Menu */}
        <div className="hidden md:flex gap-8 items-center">
          <a href="#accueil" className="hover:text-red-600 transition">
            Accueil
          </a>
          <a href="#planning" className="hover:text-red-600 transition">
            Planning
          </a>
          <a href="#coachs" className="hover:text-red-600 transition">
            Entraîneurs
          </a>
          <a href="#galerie" className="hover:text-red-600 transition">
            Galerie
          </a>
          <a href="#contact" className="hover:text-red-600 transition">
            Contact
          </a>
        </div>

        {/* Mobile Menu Button */}
        <button onClick={() => setIsOpen(!isOpen)} className="md:hidden">
          {isOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>

      {/* Mobile Menu */}
      {isOpen && (
        <div className="md:hidden bg-black border-t border-red-600 py-4 px-4 space-y-3">
          <a href="#accueil" className="block hover:text-red-600 transition">
            Accueil
          </a>
          <a href="#planning" className="block hover:text-red-600 transition">
            Planning
          </a>
          <a href="#coachs" className="block hover:text-red-600 transition">
            Entraîneurs
          </a>
          <a href="#galerie" className="block hover:text-red-600 transition">
            Galerie
          </a>
          <a href="#contact" className="block hover:text-red-600 transition">
            Contact
          </a>
        </div>
      )}
    </nav>
  )
}
