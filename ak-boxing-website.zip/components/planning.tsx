"use client"

import { useState } from "react"

const SCHEDULE_DATA = [
  {
    day: "LUNDI",
    courses: [
      { time: "19h00 – 20h00", category: "Cours FÉMININ", type: "Cardio" },
      { time: "20h00 – 21h00", category: "ADULTES", type: "Technique" },
    ],
  },
  {
    day: "MARDI",
    courses: [{ time: "20h15 – 21h15", category: "ADULTES", type: "Cardio", note: "(Yoga finit à 20h00)" }],
  },
  {
    day: "MERCREDI",
    courses: [
      { time: "15h30 – 16h00", category: "BÉBÉ", type: "5-7 ans" },
      { time: "16h30 – 17h30", category: "PRÉ-ADOS", type: "8-11 ans" },
      { time: "18h00 – 19h00", category: "ADOS", type: "12-15 ans" },
    ],
  },
  {
    day: "JEUDI",
    courses: [{ time: "20h00 – 21h00", category: "ADULTES", type: "Complet" }],
  },
  {
    day: "VENDREDI",
    courses: [
      { time: "18h30 – 19h30", category: "PRÉ-ADOS", type: "Mise de gants" },
      { time: "19h30 – 20h30", category: "ADOS", type: "Mise de gants" },
      { time: "20h30 – 21h30", category: "ADULTES", type: "Mise de gants" },
    ],
  },
  {
    day: "SAMEDI",
    courses: [
      { time: "10h00 – 11h00", category: "BÉBÉ", type: "5-7 ans" },
      { time: "11h00 – 12h00", category: "PRÉ-ADOS", type: "8-11 ans" },
      { time: "12h00 – 13h00", category: "ADOS", type: "12-15 ans" },
    ],
  },
]

export default function Planning() {
  const [selectedDay, setSelectedDay] = useState("LUNDI")

  return (
    <section id="planning" className="py-20 bg-white">
      <div className="max-w-6xl mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-4xl md:text-5xl font-bold text-black mb-4">🏆 Planning 2024/2025</h2>
          <p className="text-gray-600 text-lg">Retrouvez tous nos cours pour chaque catégorie d'âge</p>
        </div>

        <div className="grid md:grid-cols-7 gap-2 mb-8">
          {SCHEDULE_DATA.map((day) => (
            <button
              key={day.day}
              onClick={() => setSelectedDay(day.day)}
              className={`py-3 px-2 rounded-lg font-bold transition transform hover:scale-105 ${
                selectedDay === day.day ? "bg-red-600 text-white" : "bg-gray-100 text-black hover:bg-gray-200"
              }`}
            >
              {day.day}
            </button>
          ))}
        </div>

        <div className="bg-gray-50 rounded-xl p-8 border-2 border-gray-200">
          {SCHEDULE_DATA.find((d) => d.day === selectedDay)?.courses.map((course, idx) => (
            <div
              key={idx}
              className="mb-6 pb-6 border-b-2 border-gray-200 last:border-b-0 last:mb-0 last:pb-0 slide-up"
            >
              <div className="grid md:grid-cols-3 gap-4 items-center">
                <div>
                  <p className="text-red-600 font-bold text-lg">{course.time}</p>
                </div>
                <div>
                  <p className="text-black font-bold text-lg">{course.category}</p>
                  <p className="text-gray-600">{course.type}</p>
                  {course.note && <p className="text-sm text-gray-500 italic">{course.note}</p>}
                </div>
                <div className="hidden md:block text-right">
                  <button className="bg-red-600 hover:bg-red-700 text-white px-6 py-2 rounded-lg font-bold transition">
                    S'inscrire
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Informations supplémentaires */}
        <div className="grid md:grid-cols-4 gap-6 mt-12">
          <div className="bg-black text-white p-6 rounded-lg text-center">
            <p className="text-3xl font-bold text-red-600">5+</p>
            <p className="text-sm mt-2">À partir de 5 ans</p>
          </div>
          <div className="bg-black text-white p-6 rounded-lg text-center">
            <p className="text-3xl font-bold text-red-600">7</p>
            <p className="text-sm mt-2">Jours d'entraînement</p>
          </div>
          <div className="bg-black text-white p-6 rounded-lg text-center">
            <p className="text-3xl font-bold text-red-600">16h+</p>
            <p className="text-sm mt-2">Heures par semaine</p>
          </div>
          <div className="bg-black text-white p-6 rounded-lg text-center">
            <p className="text-3xl font-bold text-red-600">5</p>
            <p className="text-sm mt-2">Catégories</p>
          </div>
        </div>
      </div>
    </section>
  )
}
