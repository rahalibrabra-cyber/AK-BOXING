"use client"

import { Facebook, Instagram, Twitter } from "lucide-react"

export default function Footer() {
  return (
    <footer className="bg-black text-white py-12 border-t-4 border-red-600">
      <div className="max-w-6xl mx-auto px-4">
        <div className="grid md:grid-cols-4 gap-8 mb-8">
          {/* Logo & Description */}
          <div>
            <div className="flex items-center gap-2 mb-4">
              <div className="w-10 h-10 bg-red-600 rounded-full flex items-center justify-center font-bold text-lg">
                🥊
              </div>
              <span className="font-bold text-xl">AK BOXING</span>
            </div>
            <p className="text-gray-400 text-sm">Le meilleur club de boxe pour tous les niveaux et tous les âges.</p>
          </div>

          {/* Liens rapides */}
          <div>
            <h4 className="font-bold text-lg mb-4">Navigation</h4>
            <ul className="space-y-2 text-gray-400 text-sm">
              <li>
                <a href="#accueil" className="hover:text-red-600 transition">
                  Accueil
                </a>
              </li>
              <li>
                <a href="#planning" className="hover:text-red-600 transition">
                  Planning
                </a>
              </li>
              <li>
                <a href="#coachs" className="hover:text-red-600 transition">
                  Entraîneurs
                </a>
              </li>
              <li>
                <a href="#galerie" className="hover:text-red-600 transition">
                  Galerie
                </a>
              </li>
            </ul>
          </div>

          {/* Catégories */}
          <div>
            <h4 className="font-bold text-lg mb-4">Catégories</h4>
            <ul className="space-y-2 text-gray-400 text-sm">
              <li>
                <a href="#planning" className="hover:text-red-600 transition">
                  Bébé (5-7 ans)
                </a>
              </li>
              <li>
                <a href="#planning" className="hover:text-red-600 transition">
                  Pré-Ados (8-11 ans)
                </a>
              </li>
              <li>
                <a href="#planning" className="hover:text-red-600 transition">
                  Ados (12-15 ans)
                </a>
              </li>
              <li>
                <a href="#planning" className="hover:text-red-600 transition">
                  Adultes 16+
                </a>
              </li>
            </ul>
          </div>

          {/* Réseaux sociaux */}
          <div>
            <h4 className="font-bold text-lg mb-4">Nous suivre</h4>
            <div className="flex gap-4">
              <a
                href="#"
                className="w-10 h-10 bg-gray-800 rounded-full flex items-center justify-center hover:bg-red-600 transition"
              >
                <Facebook size={20} />
              </a>
              <a
                href="#"
                className="w-10 h-10 bg-gray-800 rounded-full flex items-center justify-center hover:bg-red-600 transition"
              >
                <Instagram size={20} />
              </a>
              <a
                href="#"
                className="w-10 h-10 bg-gray-800 rounded-full flex items-center justify-center hover:bg-red-600 transition"
              >
                <Twitter size={20} />
              </a>
            </div>
          </div>
        </div>

        {/* Divider */}
        <div className="border-t border-gray-800 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <p className="text-gray-500 text-sm">© 2025 AK Boxing. Tous droits réservés.</p>
            <p className="text-gray-400 text-sm">
              Fait avec <span className="text-red-600">♥</span> pour AK Boxing
            </p>
            <div className="flex gap-4 text-gray-500 text-sm">
              <a href="#" className="hover:text-red-600 transition">
                Politique de confidentialité
              </a>
              <a href="#" className="hover:text-red-600 transition">
                Conditions d'utilisation
              </a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  )
}
