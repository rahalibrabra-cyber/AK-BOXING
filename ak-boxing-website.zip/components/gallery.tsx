"use client"

import { useState } from "react"
import { ChevronLeft, ChevronRight, X } from "lucide-react"

const GALLERY_IMAGES = [
  {
    id: 1,
    title: "Entraînement technique",
    category: "Technique",
    image: "/boxeurs-entrainement-technique.jpg",
  },
  {
    id: 2,
    title: "Cours collectif",
    category: "Cardio",
    image: "/groupe-boxeurs-salle.jpg",
  },
  {
    id: 3,
    title: "Sparring intensif",
    category: "Compétition",
    image: "/sparring-boxe-combat.jpg",
  },
  {
    id: 4,
    title: "Jeunes boxeurs",
    category: "Junior",
    image: "/enfants-boxe-junior.jpg",
  },
  {
    id: 5,
    title: "Entraînement sac de frappe",
    category: "Technique",
    image: "/boxeur-sac-frappe.jpg",
  },
  {
    id: 6,
    title: "Compétition amateur",
    category: "Compétition",
    image: "/match-boxe-competici-n.jpg",
  },
  {
    id: 7,
    title: "Mise de gants",
    category: "Mise de gants",
    image: "/preparation-mise-gants-boxe.jpg",
  },
  {
    id: 8,
    title: "Entraînement feminin",
    category: "Féminin",
    image: "/femmes-boxeuses-entrainement.jpg",
  },
]

export default function Gallery() {
  const [selectedImage, setSelectedImage] = useState<(typeof GALLERY_IMAGES)[0] | null>(null)
  const [filter, setFilter] = useState("Tous")
  const [currentIndex, setCurrentIndex] = useState(0)

  const categories = ["Tous", "Technique", "Cardio", "Compétition", "Junior", "Féminin", "Mise de gants"]

  const filteredImages = filter === "Tous" ? GALLERY_IMAGES : GALLERY_IMAGES.filter((img) => img.category === filter)

  const handleNext = () => {
    setCurrentIndex((prev) => (prev + 1) % filteredImages.length)
  }

  const handlePrev = () => {
    setCurrentIndex((prev) => (prev - 1 + filteredImages.length) % filteredImages.length)
  }

  return (
    <section id="galerie" className="py-20 bg-black text-white">
      <div className="max-w-6xl mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-4xl md:text-5xl font-bold mb-4">
            Galerie <span className="text-red-600">Photo</span>
          </h2>
          <p className="text-gray-400 text-lg">Nos entraînements et compétitions en images</p>
        </div>

        {/* Filtres */}
        <div className="flex flex-wrap justify-center gap-3 mb-12">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => {
                setFilter(cat)
                setCurrentIndex(0)
              }}
              className={`px-4 py-2 rounded-lg font-semibold transition ${
                filter === cat ? "bg-red-600 text-white" : "bg-gray-800 text-gray-300 hover:bg-gray-700"
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Galerie Grid */}
        <div className="grid md:grid-cols-4 gap-4 mb-12">
          {filteredImages.map((img, idx) => (
            <div
              key={img.id}
              onClick={() => {
                setSelectedImage(img)
                setCurrentIndex(idx)
              }}
              className="aspect-square rounded-lg overflow-hidden cursor-pointer group"
            >
              <img
                src={img.image || "/placeholder.svg"}
                alt={img.title}
                className="w-full h-full object-cover group-hover:scale-110 transition duration-300"
              />
              <div className="absolute inset-0 bg-black/40 group-hover:bg-black/60 transition"></div>
            </div>
          ))}
        </div>

        {/* Lightbox */}
        {selectedImage && (
          <div className="fixed inset-0 bg-black/90 z-50 flex items-center justify-center p-4">
            <div className="max-w-4xl w-full relative">
              <button
                onClick={() => setSelectedImage(null)}
                className="absolute -top-10 right-0 text-white hover:text-red-600 transition"
              >
                <X size={32} />
              </button>

              <div className="relative">
                <img
                  src={filteredImages[currentIndex].image || "/placeholder.svg"}
                  alt={filteredImages[currentIndex].title}
                  className="w-full rounded-lg"
                />

                <button
                  onClick={handlePrev}
                  className="absolute left-0 top-1/2 -translate-y-1/2 -translate-x-16 text-white hover:text-red-600 transition"
                >
                  <ChevronLeft size={40} />
                </button>

                <button
                  onClick={handleNext}
                  className="absolute right-0 top-1/2 -translate-y-1/2 translate-x-16 text-white hover:text-red-600 transition"
                >
                  <ChevronRight size={40} />
                </button>

                <div className="mt-4 text-center">
                  <h3 className="text-2xl font-bold mb-1">{filteredImages[currentIndex].title}</h3>
                  <p className="text-gray-400">{filteredImages[currentIndex].category}</p>
                  <p className="text-sm text-gray-500 mt-2">
                    {currentIndex + 1} / {filteredImages.length}
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </section>
  )
}
