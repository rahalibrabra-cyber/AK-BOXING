"use client"

import Image from "next/image"

export default function Hero() {
  return (
    <section id="accueil" className="pt-24 pb-16 bg-black text-white relative overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-0 left-0 w-96 h-96 bg-red-600 rounded-full blur-3xl"></div>
        <div className="absolute bottom-0 right-0 w-96 h-96 bg-red-600 rounded-full blur-3xl"></div>
      </div>

      <div className="max-w-6xl mx-auto px-4 relative z-10">
        <div className="grid md:grid-cols-2 gap-12 items-center min-h-96">
          <div className="slide-up space-y-6">
            <h1 className="text-5xl md:text-6xl font-bold leading-tight">
              <span className="text-red-600">AK BOXING</span>
              <br />
              Forge ton esprit
            </h1>
            <p className="text-xl text-gray-300">
              Bienvenue dans le meilleur club de boxe de votre région. Des entraîneurs professionnels, une ambiance
              motivante et des cours pour tous les niveaux.
            </p>
            <div className="flex gap-4 pt-4">
              <button className="bg-red-600 hover:bg-red-700 text-white px-8 py-3 rounded-lg font-bold transition transform hover:scale-105">
                Rejoignez-nous
              </button>
              <button className="border-2 border-red-600 text-red-600 hover:bg-red-600 hover:text-white px-8 py-3 rounded-lg font-bold transition">
                En savoir plus
              </button>
            </div>
          </div>

          <div className="relative hidden md:block flex justify-center">
            <div className="flex items-center justify-center">
              <Image
                src="/images/image.png"
                alt="AK Boxing Logo"
                width={300}
                height={300}
                className="w-64 h-64 md:w-80 md:h-80 drop-shadow-lg hover:scale-105 transition duration-300"
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
