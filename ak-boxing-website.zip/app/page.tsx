"use client"

import Navigation from "@/components/navigation"
import Hero from "@/components/hero"
import Planning from "@/components/planning"
import Coaches from "@/components/coaches"
import Gallery from "@/components/gallery"
import Contact from "@/components/contact"
import Footer from "@/components/footer"

export default function Home() {
  return (
    <div className="w-full min-h-screen bg-white">
      <Navigation />
      <Hero />
      <Planning />
      <Coaches />
      <Gallery />
      <Contact />
      <Footer />
    </div>
  )
}
